﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asigurari
{   
    [Serializable]
   public class Asigurare:Clienti,ICloneable,IComparable
    {
        public String firma_asiguratoare;
        public String tip_asigurare;
        public String dataIncepereAsig;
        public String dataSfarsitAsig;

        public Asigurare():base()
        {
            firma_asiguratoare = "Anonim";
            tip_asigurare = "fara asigurare";
            dataIncepereAsig = "01/01/1990";
            dataSfarsitAsig = "01/01/2100";

        }

       

        public Asigurare(String n, int v,String c,char s,String firma,String t, String d_inc_asig, String d_sf_asig):base(n,v,c,s)
        {
            firma_asiguratoare = firma;
            tip_asigurare = t;
            dataIncepereAsig = d_inc_asig;
            dataSfarsitAsig = d_sf_asig;
        }

        public object Clone()
        {
            Asigurare a = (Asigurare)this.MemberwiseClone();
            return a;
        }

        public int CompareTo(object obj)
        {
            Asigurare asig = (Asigurare)obj;
            return String.Compare(this.dataIncepereAsig, dataIncepereAsig);

        }

        public override string ToString()
        {
            string rezultat = base.ToString() + "are o asigurare de la firma " + firma_asiguratoare + " pentru" + tip_asigurare + " incepand de la data de" + dataIncepereAsig + " cu valabilitate pana la " + dataSfarsitAsig;
            return rezultat;
        }

    }
}
