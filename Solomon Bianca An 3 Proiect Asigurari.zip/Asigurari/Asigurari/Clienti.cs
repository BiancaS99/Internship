﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asigurari
{ [Serializable]
   public  class Clienti
    {
        public String nume;
        public int varsta;
        public String CNP;
        public char sex;
        public Clienti()
        {
            nume = "Anonim";
            varsta = 0;
            CNP = "000000000000";
            sex = 'M';

        }
        public Clienti(String n,int v,String c,char s)
        {
            nume = n;
            varsta = v;
            CNP = c;
            sex = s;
        }
        public override string ToString()
        {
            return "Clientul cu numele" + nume + " are varsta de " + varsta + " cu CNP-ul: " + CNP + " si este de sex " + sex;
        }

    }
}
