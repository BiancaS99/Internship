﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Drawing.Printing;
using System.Data.OleDb;

namespace Asigurari
{
    public partial class Form2 : Form
    {
        List<Asigurare> lista2 = new List<Asigurare>();
        double[] vect = new double[20];
        int nrElem = 0;
        bool vb = false;
        const int marg = 10;
        int nr_asi_sanatate = 0;
        int nr_asig_bunuri = 0;
        int nr_asig_casco = 0;
        int sum = 0;
        int x = 10;
        Color de_sanatate = Color.Blue;
        Color de_bunuri = Color.Gray;
        Color casco = Color.Green;
        Font font = new Font(FontFamily.GenericSansSerif, 12, FontStyle.Bold);
        string connectionStr;


        public Form2(List<Asigurare> lista)
        {
            InitializeComponent();
            lista2 = lista;
            incarcaDate();
            connectionStr = " Provider= Microsoft.ACE.OLEDB.12.0; Data Source= Asigurari.accdb ";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("fisier.dat", FileMode.Open, FileAccess.Read);
            BinaryFormatter bf = new BinaryFormatter();

            List<Asigurare> lista3 = (List<Asigurare>)bf.Deserialize(fs);

            foreach (Asigurare s in lista3)
            {
                textBox1.Text += s.ToString() + Environment.NewLine;
            }

            fs.Close();

        }
        private void incarcaDate()
        {
            StreamReader sr = new StreamReader("text1.txt");
            string linie = null;
            while ((linie = sr.ReadLine()) != null)
            {
                try
                {
                    string nume = linie.Split(',')[0];
                    int varsta = Convert.ToInt32(linie.Split(',')[1]);
                    string CNP = linie.Split(',')[2];
                    char sex = Convert.ToChar(linie.Split(',')[3]);
                    string firma = linie.Split(',')[4];
                    string tip_asig = linie.Split(',')[5];
                    string data_i = linie.Split(',')[6];
                    string data_s = linie.Split(',')[7];
                    Asigurare a = new Asigurare(nume, varsta, CNP, sex, firma, tip_asig, data_i, data_s); ;
                    lista2.Add(a);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
            sr.Close();
            MessageBox.Show("au fost incarcate datele");
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            lista2.Add(new Asigurare("Marcel", 20, "1990526580035", 'M', "Aegon", "De sanatate", "01/02/2020", "01/02/2021"));
            lista2.Add(new Asigurare("Maricica", 22, "2970526580085", 'F', "Aegon", "De sanatate", "01/02/2020", "01/02/2021"));
            foreach (Asigurare a in lista2)
            {
                ListViewItem item = new ListViewItem(a.nume);
                item.SubItems.Add(a.varsta.ToString());
                item.SubItems.Add(a.CNP);
                item.SubItems.Add(a.sex.ToString());
                item.SubItems.Add(a.firma_asiguratoare);

                item.SubItems.Add(a.tip_asigurare);
                if (a.tip_asigurare == "De sanatate")
                {
                    nr_asi_sanatate += 1;
                }
                else
                {
                    if (a.tip_asigurare == "De bunuri")
                    {
                        nr_asig_bunuri += 1;
                    }
                    else
                    {
                        nr_asig_casco += 1;
                    }
                }
                
               

                item.SubItems.Add(a.dataIncepereAsig);
                item.SubItems.Add(a.dataSfarsitAsig);

                listView1.Items.Add(item);






            }
            sum += nr_asig_bunuri + nr_asig_casco + nr_asi_sanatate;
            textBox2.Text += "Numar asigurari de sanatate(albastru):" +nr_asi_sanatate+ Environment.NewLine+"Numar asigurari de bunuri (gri): "+nr_asig_bunuri+ Environment.NewLine+"Numar asigurari Casco (verde): "+nr_asig_casco + Environment.NewLine;


        }

        private void stergereToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem itm in listView1.Items)
            {
                if (itm.Selected)
                    itm.Remove();
            }
        }

        private void incarcareDinFisierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "(*.txt)|*.txt";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(ofd.FileName);
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
        }

       
    
    private void createPie()
    {
            Color[] color = { de_sanatate, de_bunuri, casco };
            int[] myPiePercent = { nr_asi_sanatate, nr_asig_bunuri, nr_asig_casco };
            Graphics g = panel1.CreateGraphics();
            float unghi = 0;
            float felie = 0;
            Rectangle r = new Rectangle(0, 0, panel1.Width-50, panel1.Height-50);
            for (int i = 0; i < myPiePercent.Length; i++)
        {
                felie = 360f * myPiePercent[i] / sum;
                g.FillPie(new SolidBrush(color[i]), r, unghi, felie);
                unghi += felie;
        }
            g.Dispose();
     
    }

            private void button3_Click(object sender, EventArgs e)
        {
            createPie();
            MessageBox.Show("e ok");
            Invalidate();
          }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void pd_print(object sender, PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            Color[] color = { de_sanatate, de_bunuri, casco };
            int[] myPiePercent = { nr_asi_sanatate, nr_asig_bunuri, nr_asig_casco };
            float unghi = 0;
            float felie = 0;
            Rectangle r = new Rectangle(0, 0, e.PageBounds.Width, e.PageBounds.Height);
            for (int i = 0; i < myPiePercent.Length; i++)
            {
                felie = 360f * myPiePercent[i] / sum;
                g.FillPie(new SolidBrush(color[i]), r, unghi, felie);
                unghi += felie;
            }
           
        }

        private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(pd_print);
            PrintPreviewDialog dlg = new PrintPreviewDialog();
            dlg.Document = pd;
            dlg.ShowDialog();
        }

        private void textBox2_MouseDown(object sender, MouseEventArgs e)
        {
            textBox2.DoDragDrop(textBox2.Text, DragDropEffects.Move);
        }

        private void panel1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.None;
            
            if ((e.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
               e.Effect = DragDropEffects.Move;
        }

        private void panel1_DragDrop(object sender, DragEventArgs e)
        {

            string text = e.Data.GetData(typeof(string)).ToString();
            Graphics g = Graphics.FromHwnd(panel1.Handle);
            g.DrawString(text, this.Font, new SolidBrush(Color.Red), x, 10);
            x += 20;
            if (x > panel1.Height)
            {
                MessageBox.Show("Nu mai este loc pe panou!");
                panel1.Invalidate();
                x = 10;
            }
            if (e.Effect == DragDropEffects.Move)
            {
                textBox2.Clear();
               
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OleDbConnection connection = new OleDbConnection(connectionStr);
            try
            {
                connection.Open();
                OleDbCommand comanda = new OleDbCommand();
                comanda.Connection = connection;
                comanda.CommandText = " SELECT * FROM Asigurari";
                OleDbDataReader dataReader = comanda.ExecuteReader();
                while (dataReader.Read())
                {
                    ListViewItem item = new ListViewItem(dataReader["Nume Client"].ToString());
                    item.SubItems.Add(dataReader["Varsta"].ToString());
                    item.SubItems.Add((dataReader["CNP"].ToString()));
                    item.SubItems.Add(dataReader["Sex"].ToString());
                    item.SubItems.Add(dataReader["Firma Asiguratoare"].ToString());

                    item.SubItems.Add(dataReader["Tip Asigurare"].ToString());
                    if (dataReader["Tip Asigurare"].ToString() == "De sanatate")
                    {
                        nr_asi_sanatate += 1;
                    }
                    else
                    {
                        if (dataReader["Tip Asigurare"].ToString() == "De bunuri")
                        {
                            nr_asig_bunuri += 1;
                        }
                        else
                        {
                            nr_asig_casco += 1;
                        }
                    }



                    item.SubItems.Add(dataReader["Data Incepere"].ToString());
                    item.SubItems.Add(dataReader["Data Expirare"].ToString());

                    listView1.Items.Add(item);






                }
                sum += nr_asig_bunuri + nr_asig_casco + nr_asi_sanatate;
                textBox2.Text += "Numar asigurari de sanatate(albastru):" + nr_asi_sanatate + Environment.NewLine + "Numar asigurari de bunuri (gri): " + nr_asig_bunuri + Environment.NewLine + "Numar asigurari Casco (verde): " + nr_asig_casco + Environment.NewLine;

            






            }
            catch (OleDbException ex)
            {
                MessageBox.Show(ex.Message);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                connection.Close();
               
            }
        }
    }
}
