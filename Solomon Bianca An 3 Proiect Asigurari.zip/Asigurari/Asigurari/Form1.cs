﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Asigurari
{
    public partial class Form1 : Form
    {
        List<Asigurare> listaAsig = new List<Asigurare>();
        string connectionStr;
        public Form1()
        {
            InitializeComponent();
            connectionStr = " Provider= Microsoft.ACE.OLEDB.12.0; Data Source= Asigurari.accdb ";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string nume = tbNume.Text;
                int varsta = Convert.ToInt32(tbVarsta.Text);
                string CNP = tbCNP.Text;
                char sex = Convert.ToChar(cbSex.Text);
                string firma = tbFirma.Text;
                string tip = cbTip.Text;
                string data_i = tbData_i.Text;
                string data_s = tbData_s.Text;
                Asigurare a = new Asigurare(nume, varsta, CNP, sex, firma, tip, data_i, data_s);
                listaAsig.Add(a);
               // incarca_in_fisier(this, e);
                save_in_file(this, e);
                MessageBox.Show(a.ToString());

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                tbNume.Clear();
                tbVarsta.Clear();
                tbCNP.Clear();
                cbSex.Text = "";
                tbFirma.Clear();
                cbTip.Text = "";
                tbData_i.Clear();
                tbData_s.Clear();
            }
        }
        private void incarca_in_fisier(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
           dlg.Filter = "(*.txt)|*.txt";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(dlg.FileName);
                sw.Write(tbNume.Text+",");
                sw.Write(Convert.ToInt32(tbVarsta.Text)+",");
                sw.Write(tbCNP.Text+",");
                sw.Write(Convert.ToChar(cbSex.Text)+",");
                sw.Write(tbFirma.Text+",");
                sw.Write(cbTip.Text+",");
                sw.Write(tbData_i.Text+",");
                sw.Write(tbData_s.Text+",");
                sw.Close();
             
            }
        }
        private void save_in_file(object sender,EventArgs e)
        {
            FileStream fs = new FileStream("fisier.dat", FileMode.Append, FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            
            bf.Serialize(fs, listaAsig);
        
            fs.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2(listaAsig);
            form.Show();
        }

        private void cbSex_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar)
                && !char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void tbVarsta_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar)
                && !char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OleDbConnection connection = new OleDbConnection(connectionStr);
            try
            {
                connection.Open();
                OleDbCommand comanda = new OleDbCommand();
                comanda.Connection = connection;
                comanda.CommandText = " INSERT INTO Asigurari VALUES(?,?,?,?,?,?,?,?)";
                comanda.Parameters.Add("Nume Client", OleDbType.Char, 255).Value = tbNume.Text;
                comanda.Parameters.Add("Varsta", OleDbType.Integer).Value = Convert.ToInt32(tbVarsta.Text);
                comanda.Parameters.Add("CNP", OleDbType.Char, 255).Value = tbCNP.Text;
                comanda.Parameters.Add("Sex", OleDbType.Char, 1).Value = cbSex.Text;
                comanda.Parameters.Add("Firma Asiguratoare", OleDbType.Char, 255).Value = tbFirma.Text;
                comanda.Parameters.Add("Tip asigurare", OleDbType.Char, 255).Value = cbTip.Text;
                comanda.Parameters.Add("Data Incepere", OleDbType.Char, 255).Value = tbData_i.Text;
                comanda.Parameters.Add("Data Expirare", OleDbType.Char, 255).Value = tbData_s.Text;
                comanda.ExecuteNonQuery();






            }
            catch (OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                connection.Close();
                tbNume.Clear();
                tbVarsta.Clear();
                tbCNP.Clear();
                cbSex.Text = "";
                tbFirma.Clear();
                cbTip.Text = "";
                tbData_i.Clear();
                tbData_s.Clear();
            }

        }
    }
}
